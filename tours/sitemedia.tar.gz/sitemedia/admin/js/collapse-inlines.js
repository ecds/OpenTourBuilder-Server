// used to collapse the inlines in the admin panel
$(function() {
    $(".collapse").removeClass("in");
})